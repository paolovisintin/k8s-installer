#include "fix_frame_channel_layout.h"
void test() {
	AVFrame *f = NULL;
	fix_frame_channel_layout(f);
}
